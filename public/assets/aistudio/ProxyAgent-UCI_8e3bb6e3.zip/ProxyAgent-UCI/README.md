# ProxyAgent UCI

![ProxyAgent UCI Logo](backend/src/assets/logo/uci_agente_proxy.png)

> **ProxyAgent UCI** es una aplicación de escritorio multiplataforma (Windows, macOS, Linux) que facilita la gestión de proxy NTLM, túneles SSH/ngrok y lanzadores de aplicaciones configuradas para usar proxy. Utiliza **Node.js + Electron** en el backend y **React + Vite** en el frontend.

---

## Tabla de Contenidos

- [Características](#características)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Requisitos](#requisitos)
- [Instalación & Desarrollo](#instalación--desarrollo)

  - [Clonar el repositorio](#clonar-el-repositorio)
  - [Instalar dependencias](#instalar-dependencias)
  - [Correr en modo desarrollo](#correr-en-modo-desarrollo)
  - [Build de producción](#build-de-producción)

- [Organización del Código](#organización-del-código)
- [Empaquetado y Distribución](#empaquetado-y-distribución)
- [Configuración](#configuración)
- [Contribución](#contribución)
- [Licencia](#licencia)

---

## Características

- **Gestión de Cuentas**: almacena múltiples credenciales NTLM con hashing seguro.
- **Configuración de Proxy**: genera y escribe configuración de CNTLM, activa/desactiva proxy de sistema.
- **Túneles SSH/ngrok**: inicia túneles dinámicos y proxy SOCKS5 con un clic.
- **Lanzamiento de Apps**: arranca aplicaciones locales (Chrome, Firefox, etc.) con proxy preconfigurado.
- **Monitoreo de Logs**: visor integrado de métricas y eventos (almacenados con `node-persist`).
- **Interface Intuitiva**: UI en React + Vite, con diseño responsive y modo claro/oscuro.

---

## Estructura del Proyecto

```
/ (raíz)
├── backend/              # Electron + Node.js (main, módulos, IPC)
│   ├── src/modules/      # Lógica de cntlm, proxy, túnel, storage, métricas
│   ├── src/components/   # Renderer (vanilla JS) para Electron UI
│   ├── main.js           # Punto de entrada principal de Electron
│   ├── preload.js        # Bridge segura para IPC
│   └── package.json
├── frontend/             # React + Vite (UI moderna)
│   ├── src/
│   ├── vite.config.js
│   └── package.json
├── assets/               # Imágenes, logos y recursos estáticos
├── .gitignore
└── README.md
```

---

## Requisitos

- **Node.js** v18+ (LTS recomendado)
- **npm** v8+ o **yarn**
- **Git**
- **Electron** v25+
- macOS: **Brew** (para instalar `cntlm`, `corkscrew`, etc.)
- Linux: gestor de paquetes (`apt`, `yum`, etc.)
- Windows: **Chocolatey** (opcional)

---

## Instalación & Desarrollo

### Clonar el repositorio

```bash
git clone https://github.com/tu-usuario/proxyagent-uci.git
cd proxyagent-uci
```

### Instalar dependencias

#### Backend (Electron)

```bash
cd backend
npm install
```

#### Frontend (React + Vite)

```bash
cd ../frontend
npm install
```

### Correr en modo desarrollo

1. Levantar backend (con hot-reload de Electron):

   ```bash
   cd backend
   npm start
   ```

2. Levantar frontend (servidor Vite):

   ```bash
   cd ../frontend
   npm run dev
   ```

3. Abre la app Electron; los cambios en React se reflejarán automáticamente.

### Build de producción

#### Frontend

```bash
cd frontend
npm run build
```

Genera `dist/` con la UI optimizada.

Copia `frontend/dist` dentro de `backend/public` (o la carpeta que sirva tu Electron).

#### Empaquetar Electron

En el directorio `backend`:

```bash
npm run package
```

> Configura tu script de empaquetado (`electron-builder` o `electron-packager`) en `package.json`.

---

## Organización del Código

- **`src/modules/`**: servicios de sistema (cntlm, proxy, túnel SSH/ngrok, storage, métricas).
- **`src/components/`**: código renderer de Electron (JS vanilla con IPC a backend).
- **`main.js`**: crea ventana, carga renderer y expone canales IPC.
- **`preload.js`**: puente seguro (`contextBridge`) ante `window.api`.
- **`frontend/src/`**: componentes React, rutas, estados y estilos.

---

## Empaquetado y Distribución

- Usa `electron-builder` o `electron-packager` para generar instaladores:

  - Windows: `.exe`, `.msi`
  - macOS: `.dmg`, `.pkg`
  - Linux: `.AppImage`, `.deb`, `.rpm`

- Configura tu pipeline CI/CD (GitHub Actions, Travis, etc.) para:

  1. Instalar dependencias
  2. Build frontend
  3. Empaquetar backend
  4. Publicar artefactos

---

## Configuración

- Variables de entorno (si aplica):

  - `NODE_ENV=development|production`

- Certificados HTTPS self-signed: el backend ignora verificación (`rejectUnauthorized: false`).
- Archivos externos:

  - `backend/config/` para claves o ajustes sensibles (quítalos con `.gitignore`).

**No subir nunca**:

```
node_modules/
*.log
dist/
backend/public/
frontend/node_modules/
frontend/dist/
config/*.key
.env
```

---

## Contribución

1. **Fork** y **clone** este repositorio.
2. Crea una rama: `git checkout -b feature/nueva-funcion`
3. Haz cambios, añade tests y documentación.
4. `git commit -m "feat: ..."`
5. `git push origin feature/nueva-funcion`
6. Abre un **Pull Request** describiendo tu aportación.

---

## Licencia

Este proyecto está bajo licencia **MIT**. Consulta [LICENSE](LICENSE) para más detalles.

---

> _Generado por el equipo ProxyAgent UCI_ > _Equipo de Desarrollo: [luissantoslezcano@gmail.com](mailto:luissantoslezcano@gmail.com).
