// src/utils/validation.js

/**
 * Valida UUID versión 4 (formato con guiones).
 * @param {string} uuid
 * @returns {boolean}
 */
function isUUID(uuid) {
  const uuidV4Regex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidV4Regex.test(uuid);
}

/**
 * Valida email básico.
 * @param {string} email
 * @returns {boolean}
 */
function isEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Valida si es un string no vacío.
 * @param {string} str
 * @returns {boolean}
 */
function isNonEmptyString(str) {
  return typeof str === 'string' && str.trim().length > 0;
}

module.exports = {
  isUUID,
  isEmail,
  isNonEmptyString,
};
