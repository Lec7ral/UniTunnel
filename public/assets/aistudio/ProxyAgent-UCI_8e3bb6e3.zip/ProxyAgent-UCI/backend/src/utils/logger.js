// src/utils/logger.js
const fs = require('fs');
const path = require('path');

const LOG_FILE = path.join(__dirname, '..', '..', 'logs', 'app.log');

function formatDate(date = new Date()) {
  return date.toISOString().replace('T', ' ').split('.')[0];
}

function log(level, message) {
  const timestamp = formatDate();
  const logMsg = `[${timestamp}] [${level.toUpperCase()}] ${message}\n`;
  try {
    fs.appendFileSync(LOG_FILE, logMsg);
  } catch (err) {
    // fallback console
    console.error('Error al escribir log:', err);
  }
}

function info(msg) {
  log('info', msg);
}

function warn(msg) {
  log('warn', msg);
}

function error(msg) {
  log('error', msg);
}

module.exports = { info, warn, error, log };
