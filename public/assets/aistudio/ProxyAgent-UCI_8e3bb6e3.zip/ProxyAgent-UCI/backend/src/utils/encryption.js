// src/utils/encryption.js
const crypto = require('crypto');

const ALGORITHM = 'aes-256-cbc';
const IV_LENGTH = 16; // bytes

/**
 * Cifra un texto con clave simétrica AES-256-CBC.
 * @param {string} text
 * @param {string} key - debe ser de 32 bytes
 * @returns {string} texto cifrado en base64 (iv + ciphertext)
 */
function encrypt(text, key) {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(key, 'utf8'), iv);
  let encrypted = cipher.update(text, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  // concatenamos iv + encrypted para almacenar/transferir
  return iv.toString('base64') + ':' + encrypted;
}

/**
 * Descifra un texto cifrado con AES-256-CBC.
 * @param {string} encryptedData - base64 (iv:ciphertext)
 * @param {string} key
 * @returns {string} texto plano descifrado
 */
function decrypt(encryptedData, key) {
  const parts = encryptedData.split(':');
  if (parts.length !== 2) throw new Error('Formato inválido para texto cifrado');
  const iv = Buffer.from(parts[0], 'base64');
  const encryptedText = parts[1];
  const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(key, 'utf8'), iv);
  let decrypted = decipher.update(encryptedText, 'base64', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

/**
 * Hashea un texto con SHA-256 y devuelve hex string.
 * @param {string} text
 * @returns {string}
 */
function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

module.exports = {
  encrypt,
  decrypt,
  sha256,
};
