// src/utils/dateUtils.js

/**
 * Formatea una fecha a ISO string sin milisegundos.
 * @param {Date|string|number} date
 * @returns {string}
 */
function toISODateString(date) {
  const d = (date instanceof Date) ? date : new Date(date);
  return d.toISOString().split('.')[0] + 'Z';
}

/**
 * Obtiene la fecha actual en ISO string sin milisegundos.
 * @returns {string}
 */
function nowISO() {
  return toISODateString(new Date());
}

/**
 * Calcula diferencia en días entre dos fechas.
 * @param {Date|string|number} date1
 * @param {Date|string|number} date2
 * @returns {number} Días (entero)
 */
function diffDays(date1, date2) {
  const d1 = (date1 instanceof Date) ? date1 : new Date(date1);
  const d2 = (date2 instanceof Date) ? date2 : new Date(date2);
  const msDiff = d2 - d1;
  return Math.floor(msDiff / (1000 * 60 * 60 * 24));
}

/**
 * Valida si una fecha está dentro de un rango.
 * @param {Date|string|number} date
 * @param {Date|string|number} start
 * @param {Date|string|number} end
 * @returns {boolean}
 */
function isWithinRange(date, start, end) {
  const d = (date instanceof Date) ? date : new Date(date);
  const s = (start instanceof Date) ? start : new Date(start);
  const e = (end instanceof Date) ? end : new Date(end);
  return d >= s && d <= e;
}

module.exports = {
  toISODateString,
  nowISO,
  diffDays,
  isWithinRange,
};
