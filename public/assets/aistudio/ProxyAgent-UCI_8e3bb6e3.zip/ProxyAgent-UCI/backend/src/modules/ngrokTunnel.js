const { execSync, spawn } = require('child_process');
const os = require('os');
const fs = require('fs');
const path = require('path');

let ngrokProcess = null;

/**
 * Ejecuta comandos con privilegios de administrador en macOS.
 * @param {string} cmd - Comando a ejecutar con sudo.
 */
function runWithSudo(cmd) {
  const esc = cmd.replace(/(["\\])/g, '\\$1');
  execSync(`osascript -e 'do shell script "${esc}" with administrator privileges'`, { stdio: 'inherit' });
}

/**
 * Inicia túnel TCP ngrok hacia localhost:22 o mediante Docker si no está instalado ngrok.
 * Devuelve una promesa con { success: boolean, url?: string, error?: string }.
 */
async function startNgrokTCP() {
  if (ngrokProcess) {
    return { success: false, error: 'Ngrok ya está corriendo.' };
  }

  // Detectar si ngrok está instalado
  let useDocker = false;
  try {
    execSync('ngrok version', { stdio: 'ignore' });
  } catch {
    useDocker = true;
  }

  const cmd = useDocker ? 'docker' : 'ngrok';
  const args = useDocker
    ? ['run', '--rm', '-p', '1080:1080', 'ngrok/ngrok', 'tcp', '22', '--log=stdout']
    : ['tcp', '22', '--log=stdout'];
  const cwd = os.homedir();

  return new Promise((resolve) => {
    let resolved = false;
    let buffer = '';

    ngrokProcess = spawn(cmd, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'] });

    ngrokProcess.stdout.on('data', (data) => {
      const text = data.toString();
      buffer += text;

      // Extraer URL pública ngrok tcp://...
      const match = text.match(/Forwarding\s+(tcp:\/\/[^\s]+)/);
      if (match && !resolved) {
        resolved = true;
        resolve({ success: true, url: match[1] });
      }
    });

    ngrokProcess.stderr.on('data', (data) => {
      buffer += data.toString();
    });

    ngrokProcess.on('error', (err) => {
      if (!resolved) {
        resolved = true;
        resolve({ success: false, error: err.message });
      }
      ngrokProcess = null;
    });

    ngrokProcess.on('close', (code) => {
      if (!resolved) {
        resolved = true;
        const errorMsg = buffer.trim() || `Ngrok salió con código ${code}`;
        resolve({ success: false, error: errorMsg });
      }
      ngrokProcess = null;
    });
  });
}

/**
 * Detiene el proceso ngrok y limpia la variable global.
 * @returns {Promise<{success:boolean,error?:string}>}
 */
async function stopNgrokTCP() {
  if (!ngrokProcess) {
    return { success: false, error: 'Ngrok no estaba corriendo.' };
  }
  try {
    ngrokProcess.kill();
    ngrokProcess = null;
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Habilita proxy SOCKS5 en todas las interfaces (macOS y Linux).
 * @returns {Promise<{success:boolean,error?:string}>}
 */
async function enableSystemSocks() {
  const platform = os.platform();

  if (platform === 'darwin' || platform === 'linux') {
    let services = [];
    try {
      services = execSync('networksetup -listallnetworkservices', { encoding: 'utf8' })
        .split('\n')
        .map(line => line.trim())
        .filter(line => line && !line.startsWith('*'));
    } catch (err) {
      return { success: false, error: 'Error listando servicios de red: ' + err.message };
    }

    if (services.length === 0) {
      return { success: false, error: 'No se encontraron servicios de red activos.' };
    }

    const commands = services.map(service =>
      `networksetup -setsocksfirewallproxy "${service}" 127.0.0.1 1080 && ` +
      `networksetup -setsocksfirewallproxystate "${service}" on`
    ).join(' && ');

    try {
      runWithSudo(commands);
    } catch (err) {
      return { success: false, error: 'Error activando SOCKS proxy: ' + err.message };
    }

    // Asegura export ALL_PROXY en ~/.zshrc o ~/.bashrc
    const rcFile = path.join(os.homedir(), platform === 'darwin' ? '.zshrc' : '.bashrc');
    try {
      const content = fs.readFileSync(rcFile, 'utf8');
      const proxyExport = `export ALL_PROXY="socks5://127.0.0.1:1080"`;
      if (!content.includes(proxyExport)) {
        fs.appendFileSync(rcFile, `\n${proxyExport}\n`, 'utf8');
      }
    } catch {
      // No es crítico, puede no existir el archivo rc
    }

    return { success: true };
  } else if (platform === 'win32') {
    try {
      execSync('netsh winhttp set proxy 127.0.0.1:1080');
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  } else {
    return { success: false, error: 'SO no compatible para SOCKS.' };
  }
}

/**
 * Desactiva proxy SOCKS5 en todas las interfaces.
 * @returns {Promise<{success:boolean,error?:string}>}
 */
async function disableSystemSocks() {
  const platform = os.platform();

  if (platform === 'darwin' || platform === 'linux') {
    let services = [];
    try {
      services = execSync('networksetup -listallnetworkservices', { encoding: 'utf8' })
        .split('\n')
        .map(line => line.trim())
        .filter(line => line && !line.startsWith('*'));
    } catch (err) {
      return { success: false, error: 'Error listando servicios de red: ' + err.message };
    }

    const commands = services.map(service =>
      `networksetup -setsocksfirewallproxystate "${service}" off`
    ).join(' && ');

    try {
      runWithSudo(commands);
    } catch (err) {
      return { success: false, error: 'Error desactivando SOCKS proxy: ' + err.message };
    }

    // Quitar export ALL_PROXY en ~/.zshrc o ~/.bashrc
    const rcFile = path.join(os.homedir(), platform === 'darwin' ? '.zshrc' : '.bashrc');
    try {
      const lines = fs.readFileSync(rcFile, 'utf8').split('\n');
      const filteredLines = lines.filter(line => !/^export ALL_PROXY=/.test(line));
      fs.writeFileSync(rcFile, filteredLines.join('\n'), 'utf8');
    } catch {
      // No es crítico
    }

    return { success: true };
  } else if (platform === 'win32') {
    try {
      execSync('netsh winhttp reset proxy');
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  } else {
    return { success: false, error: 'SO no compatible para SOCKS.' };
  }
}

module.exports = {
  startNgrokTCP,
  stopNgrokTCP,
  enableSystemSocks,
  disableSystemSocks,
};
