const storage = require('node-persist');
const path = require('path');
const { app } = require('electron');

let ready = false;

/**
 * Inicializa node-persist si no está ya inicializado.
 * Usa carpeta userData/metrics para almacenar logs.
 */
async function ensureInit() {
  if (!ready) {
    await storage.init({
      dir: path.join(app.getPath('userData'), 'metrics'),
      stringify: JSON.stringify,
      parse: JSON.parse,
      encoding: 'utf8',
      logging: false,
    });
    ready = true;
  }
}

/**
 * Registra un evento con nivel y mensaje.
 * Mantiene máximo 10,000 logs para evitar consumo excesivo.
 * @param {string} level Nivel del log (info, error, warn, etc.)
 * @param {string} message Mensaje descriptivo
 */
async function log(level, message) {
  await ensureInit();
  let logs = (await storage.getItem('logs')) || [];
  logs.unshift({
    timestamp: new Date().toISOString(),
    level,
    message,
  });
  if (logs.length > 10000) {
    logs = logs.slice(0, 10000);
  }
  await storage.setItem('logs', logs);
}

/**
 * Obtiene los últimos N logs, ordenados del más reciente al más antiguo.
 * @param {number} limit Cantidad máxima de logs a devolver (default 100)
 * @returns {Promise<Array>} Lista de logs
 */
async function getRecentLogs(limit = 100) {
  await ensureInit();
  const logs = (await storage.getItem('logs')) || [];
  return logs.slice(0, limit);
}

/**
 * Borra todos los logs almacenados.
 */
async function clearLogs() {
  await ensureInit();
  await storage.setItem('logs', []);
}

module.exports = { log, getRecentLogs, clearLogs };
