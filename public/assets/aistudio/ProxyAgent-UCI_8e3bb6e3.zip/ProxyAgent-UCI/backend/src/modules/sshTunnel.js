const { spawn, execSync } = require('child_process');
const os = require('os');

let sshProcess = null;

/**
 * Ejecuta un comando con permisos de administrador en macOS.
 * Requiere que el usuario acepte el prompt de contraseña.
 */
function runWithSudo(cmd) {
  const escaped = cmd.replace(/(["\\])/g, '\\$1');
  const as = `do shell script "${escaped}" with administrator privileges`;
  execSync(`osascript -e '${as}'`, { stdio: 'inherit' });
}

/**
 * Lista los servicios de red en macOS (excluye vacíos y líneas comentadas).
 * Útil para activar/desactivar proxies.
 */
function listNetworkServices() {
  try {
    return execSync('networksetup -listallnetworkservices', { encoding: 'utf8' })
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('*'));
  } catch (err) {
    // Podrías loggear aquí si quieres
    return [];
  }
}

/**
 * Inicia un túnel SSH dinámico (SOCKS5) en localhost:1080,
 * usando un proxy CNTLM (puerto 3127) vía corkscrew para salto.
 */
async function startTunnel() {
  if (sshProcess) {
    return { success: false, error: 'El túnel SSH ya está en ejecución.' };
  }

  const args = [
    '-N', // no ejecutar comandos remotos
    '-D', '1080', // túnel SOCKS5 local
    '-o', 'ExitOnForwardFailure=yes',
    '-o', 'ServerAliveInterval=60',
    '-o', 'ProxyCommand=corkscrew 127.0.0.1 3127 ssh.localhost.run 22',
    'ssh.localhost.run'
  ];

  sshProcess = spawn('ssh', args, { detached: true, stdio: ['ignore', 'pipe', 'pipe'] });

  let started = false;
  let errorLog = '';

  return new Promise(resolve => {
    sshProcess.stderr.on('data', data => {
      const str = data.toString();
      errorLog += str;
      if (!started && /Authenticated|Allocated/.test(errorLog)) {
        started = true;
        resolve({ success: true });
      }
    });

    sshProcess.on('error', err => {
      sshProcess = null;
      resolve({ success: false, error: err.message || errorLog.trim() });
    });

    sshProcess.on('exit', code => {
      if (!started) {
        const msg = errorLog.trim() || `El proceso ssh terminó con código ${code}`;
        sshProcess = null;
        resolve({ success: false, error: msg });
      }
    });

    // Timeout fallback: si no hay error en 5s, asumimos éxito
    setTimeout(() => {
      if (!started) {
        started = true;
        resolve({ success: true });
      }
    }, 5000);
  });
}

/**
 * Detiene el túnel SSH dinámico y mata el proceso y grupo.
 */
async function stopTunnel() {
  if (!sshProcess) {
    return { success: false, error: 'No hay ningún túnel SSH activo.' };
  }
  try {
    process.kill(-sshProcess.pid, 'SIGTERM'); // mata todo el grupo de procesos
    sshProcess = null;
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Activa proxy SOCKS (127.0.0.1:1080) en todas las interfaces del sistema.
 * Implementa soporte para macOS, Linux y Windows.
 */
async function enableSocks() {
  try {
    const platform = os.platform();

    if (platform === 'darwin') {
      const services = listNetworkServices();
      if (!services.length) throw new Error('No se encontraron servicios de red activos.');

      const commands = services.map(service =>
        `networksetup -setsocksfirewallproxy "${service}" 127.0.0.1 1080 && ` +
        `networksetup -setsocksfirewallproxystate "${service}" on`
      ).join(' && ');

      runWithSudo(commands);
      return { success: true };

    } else if (platform === 'linux') {
      execSync('gsettings set org.gnome.system.proxy mode manual');
      execSync('gsettings set org.gnome.system.proxy.socks host 127.0.0.1');
      execSync('gsettings set org.gnome.system.proxy.socks port 1080');
      return { success: true };

    } else if (platform === 'win32') {
      execSync('netsh winhttp set proxy 127.0.0.1:1080');
      return { success: true };

    } else {
      throw new Error('Sistema operativo no compatible para activar proxy SOCKS');
    }
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Desactiva proxy SOCKS en todas las interfaces del sistema.
 */
async function disableSocks() {
  try {
    const platform = os.platform();

    if (platform === 'darwin') {
      const services = listNetworkServices();
      if (!services.length) throw new Error('No se encontraron servicios de red activos.');

      const commands = services.map(service =>
        `networksetup -setsocksfirewallproxystate "${service}" off`
      ).join(' && ');

      runWithSudo(commands);
      return { success: true };

    } else if (platform === 'linux') {
      execSync('gsettings set org.gnome.system.proxy mode none');
      return { success: true };

    } else if (platform === 'win32') {
      execSync('netsh winhttp reset proxy');
      return { success: true };

    } else {
      throw new Error('Sistema operativo no compatible para desactivar proxy SOCKS');
    }
  } catch (err) {
    return { success: false, error: err.message };
  }
}

module.exports = {
  startTunnel,
  stopTunnel,
  enableSocks,
  disableSocks
};
