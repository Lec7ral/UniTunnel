const { execSync } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');

/**
 * Ejecuta un bloque de shell con privilegios de administrador en macOS.
 * Importante: Esto debe ejecutarse SOLO en el cliente, no en servidores remotos.
 */
function runWithSudo(cmd) {
  const esc = cmd.replace(/(["\\])/g, '\\$1');
  const as = `do shell script "${esc}" with administrator privileges`;
  try {
    execSync(`osascript -e '${as}'`, { stdio: 'inherit' });
  } catch (error) {
    throw new Error(`Error ejecutando comando sudo: ${error.message}`);
  }
}

/**
 * Busca ruta de brew en las ubicaciones usuales o sistema.
 */
function findBrewPath() {
  try {
    const brewPath = execSync('which brew', { encoding: 'utf8' }).trim();
    if (fs.existsSync(brewPath)) return brewPath;
  } catch {}
  for (const p of ['/opt/homebrew/bin/brew', '/usr/local/bin/brew']) {
    if (fs.existsSync(p)) return p;
  }
  return 'brew'; // fallback seguro
}

/**
 * Busca binario cntlm en rutas estándar o sistema.
 */
function findCntlmBin() {
  const candidates = ['/opt/homebrew/bin/cntlm', '/usr/local/bin/cntlm', '/usr/bin/cntlm', 'cntlm'];
  for (const p of candidates) {
    try {
      if (p === 'cntlm' || fs.existsSync(p)) return p;
    } catch {}
  }
  throw new Error('No se encontró el binario cntlm en el sistema');
}

/**
 * Genera hashes PassLM, PassNT, PassNTLMv2 ejecutando `cntlm -H`.
 */
function generateHashes(user, domain, password) {
  try {
    const bin = findCntlmBin();
    const safePass = password.replace(/"/g, '\\"');
    const raw = execSync(`echo "${safePass}" | "${bin}" -H -u "${user}" -d "${domain}"`, { encoding: 'utf8' });
    const lines = raw.split('\n');
    const getHash = (label) => {
      const line = lines.find(l => l.trim().startsWith(label));
      return line ? line.split(/\s+/)[1] : null;
    };
    return {
      success: true,
      passLM: getHash('PassLM'),
      passNT: getHash('PassNT'),
      passNTLMv2: getHash('PassNTLMv2'),
      output: raw,
    };
  } catch (error) {
    return { success: false, error: `Error generando hashes CNTLM: ${error.message}` };
  }
}

/**
 * Escribe el archivo cntlm.conf temporal y lo mueve a /opt/homebrew/etc/cntlm.conf con permisos adecuados.
 */
function writeCntlmConf(user, domain, passLM, passNT, passNTLMv2) {
  const tmpDir = path.join(os.homedir(), 'Library', 'Application Support', 'ProxyAgent');
  const tmpPath = path.join(tmpDir, 'cntlm.conf.tmp');
  const finalPath = '/opt/homebrew/etc/cntlm.conf';

  try {
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

    try { fs.unlinkSync(tmpPath); } catch {}

    const lines = [
      `Username    ${user}`,
      `Domain      ${domain}`,
      `PassLM      ${passLM}`,
      `PassNT      ${passNT}`,
      `PassNTLMv2  ${passNTLMv2}`,
      `Auth        NTLMv2`,
      `Proxy       10.0.0.1:8080`,      // Podrías hacer configurable esto
      `Listen      127.0.0.1:3127`,     // Igual configurable si se requiere
    ];

    fs.writeFileSync(tmpPath, lines.join('\n') + '\n', 'utf8');

    runWithSudo(`rm -f "${finalPath}" && mv "${tmpPath}" "${finalPath}"`);

    try { fs.unlinkSync(tmpPath); } catch {}

    return { success: true, path: finalPath };
  } catch (error) {
    return { success: false, error: `Error escribiendo cntlm.conf: ${error.message}` };
  }
}

/**
 * Reinicia el servicio CNTLM usando brew services.
 * Importante: Solo debe hacerse en cliente local (no remoto ni root compartido).
 */
function restartCntlmService() {
  const brew = findBrewPath();
  const plist = path.join(os.homedir(), 'Library', 'LaunchAgents', 'homebrew.mxcl.cntlm.plist');

  try {
    // Parar servicios y matar procesos huérfanos
    execSync(`"${brew}" services stop cntlm`, { stdio: 'ignore' });
    execSync('pkill cntlm', { stdio: 'ignore' });
    execSync(`"${brew}" services remove cntlm`, { stdio: 'ignore' });
    try { fs.unlinkSync(plist); } catch {}
    execSync('lsof -ti tcp:3127 | xargs kill -9', { stdio: 'ignore' });

    // Iniciar servicio fresco
    execSync(`"${brew}" services start cntlm`, { stdio: 'inherit' });

    return { success: true };
  } catch (error) {
    return { success: false, error: `Error reiniciando CNTLM: ${error.message}` };
  }
}

/**
 * Detiene el servicio CNTLM.
 */
function stopCntlmService() {
  const brew = findBrewPath();
  try {
    execSync(`"${brew}" services stop cntlm`, { stdio: 'ignore' });
    execSync('pkill cntlm', { stdio: 'ignore' });
    return { success: true };
  } catch (error) {
    return { success: false, error: `Error deteniendo CNTLM: ${error.message}` };
  }
}

module.exports = {
  generateHashes,
  writeCntlmConf,
  restartCntlmService,
  stopCntlmService,
};
