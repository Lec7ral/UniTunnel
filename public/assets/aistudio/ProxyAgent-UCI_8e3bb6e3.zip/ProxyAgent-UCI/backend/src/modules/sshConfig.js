const fs = require('fs');
const os = require('os');
const path = require('path');

const SSH_DIR = path.join(os.homedir(), '.ssh');
const CONFIG_PATH = path.join(SSH_DIR, 'config');

/**
 * Bloque SSH que garantizamos en ~/.ssh/config.
 * Ajusta los valores según tu servidor.
 */
const SSH_BLOCK = [
  'Host uci-ssh',
  '    HostName mi.ssh.servidor.remoto.com',
  '    Port 22',
  '    User mi_usuario_ssh',
  '    ProxyCommand corkscrew 127.0.0.1 3127 %h %p'
].join('\n') + '\n\n';

/**
 * Asegura que ~/.ssh exista con permisos 700.
 */
function ensureSshDir() {
  try {
    if (!fs.existsSync(SSH_DIR)) {
      fs.mkdirSync(SSH_DIR, { mode: 0o700, recursive: true });
    } else {
      fs.chmodSync(SSH_DIR, 0o700);
    }
  } catch (err) {
    throw new Error(`Error asegurando directorio SSH: ${err.message}`);
  }
}

/**
 * Lee ~/.ssh/config o devuelve cadena vacía si no existe.
 */
function readConfig() {
  try {
    return fs.readFileSync(CONFIG_PATH, 'utf8');
  } catch {
    return '';
  }
}

/**
 * Escribe contenido en ~/.ssh/config con permisos 600.
 */
function writeConfig(content) {
  try {
    fs.writeFileSync(CONFIG_PATH, content, { encoding: 'utf8', mode: 0o600 });
  } catch (err) {
    throw new Error(`Error escribiendo archivo config SSH: ${err.message}`);
  }
}

/**
 * Detecta si ya existe un bloque con "Host uci-ssh".
 */
function hasSshBlock(content) {
  return /Host\s+uci-ssh/.test(content);
}

/**
 * Garantiza que el bloque SSH_BLOCK esté en ~/.ssh/config.
 * Si falta, lo añade al final y asegura permisos.
 */
function ensureSshConfig() {
  ensureSshDir();

  const existing = readConfig();

  if (hasSshBlock(existing)) {
    return { success: true, message: 'SSH config ya tenía el bloque.' };
  }

  // Si había contenido previo y no acaba en salto de línea, añadir uno
  const prefix = existing.endsWith('\n') ? existing : existing + '\n';
  const newContent = prefix + SSH_BLOCK;

  writeConfig(newContent);
  return { success: true, message: 'Bloque SSH agregado a ~/.ssh/config.' };
}

module.exports = { ensureSshConfig };
