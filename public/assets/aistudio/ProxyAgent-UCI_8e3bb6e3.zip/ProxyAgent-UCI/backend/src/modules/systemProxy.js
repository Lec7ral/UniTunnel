const { execSync } = require('child_process');
const os = require('os');
const fs = require('fs');
const path = require('path');

/**
 * Ejecuta un bloque de comandos con privilegios de administrador (macOS).
 */
function runWithSudo(cmd) {
  const esc = cmd.replace(/(["\\])/g, '\\$1');
  const as = `do shell script "${esc}" with administrator privileges`;
  execSync(`osascript -e '${as}'`, { stdio: 'inherit' });
}

/**
 * Añade o actualiza una variable de entorno en el archivo dado.
 */
function addOrUpdateEnvVar(rcPath, name, value) {
  let lines = [];
  try {
    lines = fs.readFileSync(rcPath, 'utf8').split('\n');
  } catch {
    // archivo no existe, será creado luego
  }
  const exportLine = `export ${name}="${value}"`;
  const re = new RegExp(`^\\s*export\\s+${name}=`);
  let found = false;
  lines = lines.map(l => {
    if (re.test(l)) {
      found = true;
      return exportLine;
    }
    return l;
  });
  if (!found) lines.push(exportLine);
  fs.writeFileSync(rcPath, lines.join('\n'), 'utf8');
}

/**
 * Elimina una variable de entorno del archivo dado.
 */
function removeEnvVar(rcPath, name) {
  let lines = [];
  try {
    lines = fs.readFileSync(rcPath, 'utf8').split('\n');
  } catch {
    return;
  }
  const re = new RegExp(`^\\s*export\\s+${name}=`);
  lines = lines.filter(l => !re.test(l));
  fs.writeFileSync(rcPath, lines.join('\n'), 'utf8');
}

/**
 * Activa el proxy de sistema en macOS, Linux o Windows.
 */
async function setSystemProxy() {
  try {
    const home = os.homedir();
    const zshrc = path.join(home, '.zshrc');
    const plat = os.platform();

    if (plat === 'darwin') {
      // Obtiene servicios activos: omite cabecera y líneas con '*'
      const raw = execSync(
        'networksetup -listallnetworkservices | tail -n +2 | grep -v "^\\*"',
        { encoding: 'utf8' }
      )
        .split('\n')
        .map(l => l.trim())
        .filter(Boolean);

      if (!raw.length) throw new Error('No se encontraron network services activos.');

      // Construye bloque único de comandos para todos los servicios
      const cmds = raw.map(s =>
        `networksetup -setwebproxy "${s}" 127.0.0.1 3127 && ` +
        `networksetup -setsecurewebproxy "${s}" 127.0.0.1 3127 && ` +
        `networksetup -setwebproxystate "${s}" on && ` +
        `networksetup -setsecurewebproxystate "${s}" on`
      ).join(' && ');

      runWithSudo(cmds);

      addOrUpdateEnvVar(zshrc, 'http_proxy', 'http://127.0.0.1:3127');
      addOrUpdateEnvVar(zshrc, 'https_proxy', 'http://127.0.0.1:3127');

    } else if (plat === 'linux') {
      const cmds =
        `gsettings set org.gnome.system.proxy mode 'manual' && ` +
        `gsettings set org.gnome.system.proxy.http host '127.0.0.1' && ` +
        `gsettings set org.gnome.system.proxy.http port 3127 && ` +
        `gsettings set org.gnome.system.proxy.https host '127.0.0.1' && ` +
        `gsettings set org.gnome.system.proxy.https port 3127`;
      runWithSudo(cmds);

      addOrUpdateEnvVar(zshrc, 'http_proxy', 'http://127.0.0.1:3127');
      addOrUpdateEnvVar(zshrc, 'https_proxy', 'http://127.0.0.1:3127');

    } else if (plat === 'win32') {
      execSync(`netsh winhttp set proxy 127.0.0.1:3127`);
      execSync(
        `REG ADD "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" ` +
        `/v ProxyEnable /t REG_DWORD /d 1 /f`
      );
      execSync(
        `REG ADD "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" ` +
        `/v ProxyServer /t REG_SZ /d "127.0.0.1:3127" /f`
      );
    } else {
      throw new Error('SO no compatible para configurar proxy de sistema');
    }

    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Desactiva el proxy de sistema en macOS, Linux o Windows.
 */
async function disableSystemProxy() {
  try {
    const home = os.homedir();
    const zshrc = path.join(home, '.zshrc');
    const plat = os.platform();

    if (plat === 'darwin') {
      const svcs = execSync(
        'networksetup -listallnetworkservices | tail -n +2 | grep -v "^\\*"',
        { encoding: 'utf8' }
      )
        .split('\n')
        .map(l => l.trim())
        .filter(Boolean);

      if (!svcs.length) throw new Error('No se encontraron network services activos.');

      const cmds = svcs.map(s =>
        `networksetup -setwebproxystate "${s}" off && ` +
        `networksetup -setsecurewebproxystate "${s}" off`
      ).join(' && ');

      runWithSudo(cmds);

      removeEnvVar(zshrc, 'http_proxy');
      removeEnvVar(zshrc, 'https_proxy');

    } else if (plat === 'linux') {
      runWithSudo(`gsettings set org.gnome.system.proxy mode 'none'`);

      removeEnvVar(zshrc, 'http_proxy');
      removeEnvVar(zshrc, 'https_proxy');

    } else if (plat === 'win32') {
      execSync(`netsh winhttp reset proxy`);
      execSync(
        `REG ADD "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" ` +
        `/v ProxyEnable /t REG_DWORD /d 0 /f`
      );
    } else {
      throw new Error('SO no compatible para desactivar proxy de sistema');
    }

    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

module.exports = {
  setSystemProxy,
  disableSystemProxy,
};
