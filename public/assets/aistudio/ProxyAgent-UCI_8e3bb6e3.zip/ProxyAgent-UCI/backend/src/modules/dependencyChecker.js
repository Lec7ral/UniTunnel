const { execSync } = require('child_process');
const os = require('os');

/**
 * Verifica si un comando está disponible en PATH.
 * @param {string} cmd
 * @returns {boolean}
 */
function isInstalled(cmd) {
  try {
    if (process.platform === 'win32') {
      execSync(`where ${cmd}`, { stdio: 'ignore' });
    } else {
      execSync(`which ${cmd}`, { stdio: 'ignore' });
    }
    return true;
  } catch {
    return false;
  }
}

/**
 * Detecta el gestor de paquetes disponible para la plataforma.
 * @returns {'brew'|'apt'|'choco'|null}
 */
function detectPackageManager() {
  const plat = process.platform;
  try {
    if (plat === 'darwin') {
      execSync('brew --version', { stdio: 'ignore' });
      return 'brew';
    }
    if (plat === 'linux') {
      execSync('apt --version', { stdio: 'ignore' });
      return 'apt';
    }
    if (plat === 'win32') {
      execSync('choco --version', { stdio: 'ignore' });
      return 'choco';
    }
  } catch {
    return null;
  }
  return null;
}

/**
 * Devuelve el comando para instalar un paquete según gestor detectado.
 * @param {string} pkgName 
 * @returns {string}
 */
function makeInstallCmd(pkgName) {
  const pm = detectPackageManager();
  switch (pm) {
    case 'brew':
      return `brew install ${pkgName}`;
    case 'apt':
      return `sudo apt install ${pkgName}   # o usa tu gestor de paquetes`;
    case 'choco':
      return `choco install ${pkgName}`;
    default:
      return `Instala ${pkgName} manualmente en tu sistema`;
  }
}

/**
 * Lista las dependencias necesarias para el sistema.
 * @returns {Array<{name: string, cmds: string[]}>}
 */
function getRequiredDeps() {
  const plat = process.platform;
  const deps = [
    { name: 'cntlm', cmds: ['cntlm'] },
    { name: 'ssh',   cmds: ['ssh'] },
    { name: 'ngrok', cmds: ['ngrok'] },
  ];

  // Agregar corkscrew solo en macOS/Linux
  if (plat === 'darwin' || plat === 'linux') {
    deps.push({ name: 'corkscrew', cmds: ['corkscrew'] });
  }

  return deps;
}

/**
 * Revisa todas las dependencias y su estado.
 * @returns {Array<{name: string, installed: boolean, install: {cmd: string, auto: boolean}}>}
 */
function checkAllDeps() {
  const pm = detectPackageManager();
  return getRequiredDeps().map(dep => {
    const installed = dep.cmds.some(cmd => isInstalled(cmd));
    return {
      name: dep.name,
      installed,
      install: {
        cmd: makeInstallCmd(dep.name),
        auto: pm !== null
      }
    };
  });
}

module.exports = {
  checkAllDeps,
  detectPackageManager,
  isInstalled,
  getRequiredDeps,
};
