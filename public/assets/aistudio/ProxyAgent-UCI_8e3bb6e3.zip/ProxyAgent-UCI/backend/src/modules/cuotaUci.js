const axios = require('axios');
const https = require('https');

function fixToJsonString(str) {
  return str.replace(/([{,]\s*)([a-zA-Z0-9_]+)\s*:/g, '$1"$2":');
}

async function consultarCuota(username, password) {
  try {
    const base64Pass = Buffer.from(password).toString('base64');

    const httpsAgent = new https.Agent({
      rejectUnauthorized: false,
    });

    const params = new URLSearchParams();
    params.append('username', username);
    params.append('userpassword', base64Pass);

    const response = await axios.post('https://cuota.uci.cu/php/cuota.php', params.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      httpsAgent,
      validateStatus: () => true,
      responseType: 'text',  // para que no intente parsear
    });

    console.log('RAW response.data:', response.data);

    // Corregir formato para JSON válido
    const fixedStr = fixToJsonString(response.data);

    let dataObj;
    try {
      dataObj = JSON.parse(fixedStr);
    } catch (parseError) {
      console.error('Error en JSON.parse:', parseError.message);
      return { success: false, error: 'Respuesta JSON inválida' };
    }

    if (dataObj.success) {
      return { success: true, data: dataObj.data };
    } else {
      return { success: false, error: dataObj.msg || 'Error desconocido' };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
}

module.exports = { consultarCuota };
