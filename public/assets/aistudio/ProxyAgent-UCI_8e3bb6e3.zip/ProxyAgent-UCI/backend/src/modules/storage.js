const storage = require('node-persist');
const path = require('path');
const { app } = require('electron');
const keytar = require('keytar');

// Estado interno para evitar inicializaciones múltiples
let ready = false;

/**
 * Inicializa node-persist en la carpeta userData/accounts.
 */
async function ensureInit() {
  if (!ready) {
    await storage.init({
      dir: path.join(app.getPath('userData'), 'accounts'),
      stringify: JSON.stringify,
      parse: JSON.parse,
      encoding: 'utf8',
      logging: false,
    });
    ready = true;
  }
}

/**
 * Añade una cuenta sin contraseña (password se guarda en Keytar).
 * @param {Object} account - { user, domain, hashLM, hashNT, hashNTLMv2 }
 */
async function addAccount(account) {
  await ensureInit();
  const accounts = (await storage.getItem('accounts')) || [];
  accounts.push(account);
  await storage.setItem('accounts', accounts);
}

/**
 * Obtiene todas las cuentas.
 * @returns {Array}
 */
async function getAccounts() {
  await ensureInit();
  return (await storage.getItem('accounts')) || [];
}

/**
 * Guarda una lista completa de cuentas (ej. después de borrar una).
 * @param {Array} accounts
 */
async function saveAccounts(accounts) {
  await ensureInit();
  await storage.setItem('accounts', accounts);
}

/**
 * Guarda la contraseña en el llavero (Keytar) para mayor seguridad.
 * @param {string} user
 * @param {string} domain
 * @param {string} password
 */
async function storePassword(user, domain, password) {
  const service = 'ProxyAgent UCI';
  const account = `${user}@${domain}`;
  await keytar.setPassword(service, account, password);
}

/**
 * Obtiene la contraseña almacenada para un usuario y dominio.
 * @param {string} user
 * @param {string} domain
 * @returns {string|null}
 */
async function getPassword(user, domain) {
  const service = 'ProxyAgent UCI';
  const account = `${user}@${domain}`;
  return await keytar.getPassword(service, account);
}

/**
 * Borra la contraseña del llavero para un usuario y dominio.
 * @param {string} user
 * @param {string} domain
 */
async function deletePassword(user, domain) {
  const service = 'ProxyAgent UCI';
  const account = `${user}@${domain}`;
  await keytar.deletePassword(service, account);
}

module.exports = {
  addAccount,
  getAccounts,
  saveAccounts,
  storePassword,
  getPassword,
  deletePassword,
};
