// src/preload.js
const { contextBridge, ipcRenderer } = require('electron');

/**
 * Wrapper para ipcRenderer.invoke con captura de errores.
 */
async function invoke(channel, args) {
  try {
    return await ipcRenderer.invoke(channel, args);
  } catch (err) {
    console.error(`IPC error on "${channel}":`, err);
    throw err;
  }
}

contextBridge.exposeInMainWorld('api', {
  // CNTLM / Proxy
  generateHashes: ({ user, domain, password }) =>
    invoke('generate-hashes', { user, domain, password }),

  writeCntlmConf: ({ user, domain, passLM, passNT, passNTLMv2 }) =>
    invoke('write-cntlm-conf', { user, domain, passLM, passNT, passNTLMv2 }),

  restartCntlmService: () =>
    invoke('restart-cntlm-service'),

  stopCntlmService: () =>
    invoke('stop-cntlm-service'),

  setSystemProxy: () =>
    invoke('set-system-proxy'),

  disableSystemProxy: () =>
    invoke('disable-system-proxy'),

  // Cuentas seguras (Lowdb + Keytar)
  getAccounts: () =>
    invoke('get-accounts'),

  addAccount: ({ user, domain, password, hashLM, hashNT, hashNTLMv2 }) =>
    invoke('add-account', { user, domain, password, hashLM, hashNT, hashNTLMv2 }),

  deleteAccount: ({ user, domain }) =>
    invoke('delete-account', { user, domain }),

  // Recuperar password de Keytar (debes exponer handler 'get-password' en ipcHandlers.js)
  getPassword: (user, domain) =>
    invoke('get-password', { user, domain }),

  // Métricas/logs
  getRecentLogs: (limit = 50) =>
    invoke('get-recent-logs', limit),

  // Dependencias & Instalación
  getDependencies: () =>
    invoke('get-dependencies'),

  runInstallCommand: (cmd) =>
    invoke('run-install-cmd', cmd),

  // Aplicaciones
  getAppList: () =>
    invoke('get-app-list'),

  launchApp: (appData) =>
    invoke('launch-app', appData),

  // SSH Tunnel + SOCKS
  startServeoTunnel: () =>
    invoke('start-ssh-tunnel'),

  stopServeoTunnel: () =>
    invoke('stop-ssh-tunnel'),

  enableSocks: () =>
    invoke('enable-socks'),

  disableSocks: () =>
    invoke('disable-socks'),
});
