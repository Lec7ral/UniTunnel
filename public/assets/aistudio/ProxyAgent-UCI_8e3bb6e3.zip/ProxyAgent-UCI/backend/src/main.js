const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, execSync } = require('child_process');

// Registramos IPC handlers usando rutas absolutas
require(path.join(__dirname, 'modules', 'ipcHandlers'));

const sshConfig = require(path.join(__dirname, 'modules', 'sshConfig'));

/** 
 * Obtiene la ruta de brew según arquitectura
 */
function findBrewPath() {
  for (const p of ['/opt/homebrew/bin/brew', '/usr/local/bin/brew']) {
    if (fs.existsSync(p)) return p;
  }
  return 'brew';
}

/**
 * Escanea las apps de macOS y retorna lista
 */
function getAppList() {
  const apps = [];
  const dirs = [
    '/Applications',
    path.join(app.getPath('home'), 'Applications')
  ];
  dirs.forEach(dir => {
    try {
      fs.readdirSync(dir).forEach(file => {
        if (file.endsWith('.app')) {
          apps.push({
            name: file.replace(/\.app$/, ''),
            fullPath: path.join(dir, file)
          });
        }
      });
    } catch {
      // directorio no existe o no accesible
    }
  });
  return apps.sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Lanza una .app con variables de proxy
 */
function launchAppWithProxy({ fullPath, name }) {
  return new Promise((resolve, reject) => {
    const env = {
      ...process.env,
      http_proxy: 'http://127.0.0.1:3127',
      https_proxy: 'http://127.0.0.1:3127'
    };
    const child = spawn('open', ['-a', fullPath], { env });
    let err = '';
    child.on('error', e => err = e.message);
    child.on('close', code => {
      if (code === 0) {
        resolve({ success: true, name });
      } else {
        reject({ success: false, name, error: err || `Exited with code ${code}` });
      }
    });
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 900,
    height: 700,
    minWidth: 800,
    minHeight: 600,
    resizable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, 'index.html'));

  // Opcional: abrir DevTools para debugging (descomenta si quieres)
  // win.webContents.openDevTools();
}

app.whenReady().then(() => {
  const brew = findBrewPath();
  const plist = path.join(
    app.getPath('home'),
    'Library',
    'LaunchAgents',
    'homebrew.mxcl.cntlm.plist'
  );

  // 1) Limpiar posible plist corrupto de cntlm
  try {
    if (fs.existsSync(plist)) {
      fs.unlinkSync(plist);
      console.log('[DEBUG] Eliminado plist CNTLM:', plist);
    }
    execSync(`"${brew}" services cleanup`, { stdio: 'ignore' });
    console.log('[DEBUG] brew services cleanup OK');
  } catch (e) {
    console.warn('[WARN] Error limpiando plist o brew cleanup:', e.message);
  }

  // 2) Asegurar bloque SSH config
  try {
    const res = sshConfig.ensureSshConfig();
    console.log('[DEBUG] sshConfig:', res.message);
  } catch (e) {
    console.error('[ERROR] sshConfig fallo:', e);
  }

  createWindow();

  // IPC para listado de apps
  ipcMain.handle('get-app-list', () => getAppList());

  // IPC para lanzar app
  ipcMain.handle('launch-app', async (_, appData) => {
    try {
      return await launchAppWithProxy(appData);
    } catch (err) {
      return err;
    }
  });

  // Reabrir ventana en macOS
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Salir en Windows/Linux al cerrar todas las ventanas
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
