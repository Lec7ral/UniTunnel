const sshConfigModule = require('../modules/sshConfig');
const logger = require('../utils/logger');

/**
 * Servicio para gestionar configuración SSH.
 */
async function ensureConfig() {
  try {
    const result = sshConfigModule.ensureSshConfig();
    if (result.success) {
      logger.info('Configuración SSH asegurada correctamente');
    } else {
      logger.warn(`Configuración SSH con resultado no exitoso: ${result.message || 'sin mensaje'}`);
    }
    return result;
  } catch (error) {
    logger.error(`Error asegurando configuración SSH: ${error.message}`);
    return { success: false, message: error.message };
  }
}

module.exports = { ensureConfig };
