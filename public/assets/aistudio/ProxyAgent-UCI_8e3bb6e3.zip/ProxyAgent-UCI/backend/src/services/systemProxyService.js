const systemProxyModule = require('../modules/systemProxy');
const logger = require('../utils/logger');

/**
 * Activa proxy de sistema.
 */
async function enableSystemProxy() {
  try {
    const res = await systemProxyModule.setSystemProxy();
    if (res.success) {
      logger.info('Proxy de sistema activado');
    } else {
      logger.error('Error activando proxy de sistema: ' + res.error);
    }
    return res;
  } catch (error) {
    logger.error('Excepción activando proxy de sistema: ' + error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Desactiva proxy de sistema.
 */
async function disableSystemProxy() {
  try {
    const res = await systemProxyModule.disableSystemProxy();
    if (res.success) {
      logger.info('Proxy de sistema desactivado');
    } else {
      logger.error('Error desactivando proxy de sistema: ' + res.error);
    }
    return res;
  } catch (error) {
    logger.error('Excepción desactivando proxy de sistema: ' + error.message);
    return { success: false, error: error.message };
  }
}

module.exports = {
  enableSystemProxy,
  disableSystemProxy
};
