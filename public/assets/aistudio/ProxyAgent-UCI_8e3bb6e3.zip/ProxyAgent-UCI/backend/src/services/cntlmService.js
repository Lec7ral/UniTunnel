const cntlmModule = require('../modules/cntlm');
const { isNonEmptyString } = require('../utils/validation');
const logger = require('../utils/logger');

async function generateHashes(user, domain, password) {
  // Validaciones con utils
  if (!isNonEmptyString(user) || !isNonEmptyString(domain) || !isNonEmptyString(password)) {
    logger.error('generateHashes: Usuario, dominio y contraseña son requeridos');
    throw new Error('Usuario, dominio y contraseña son requeridos');
  }
  
  try {
    const result = cntlmModule.generateHashes(user, domain, password);
    logger.info(`Hashes generados para ${user}@${domain}`);
    return result;
  } catch (error) {
    logger.error(`Error generando hashes CNTLM para ${user}@${domain}: ${error.message}`);
    throw new Error('Error generando hashes CNTLM: ' + error.message);
  }
}

async function writeCntlmConf(user, domain, passLM, passNT, passNTLMv2) {
  try {
    const res = cntlmModule.writeCntlmConf(user, domain, passLM, passNT, passNTLMv2);
    logger.info(`cntlm.conf escrito para ${user}@${domain}`);
    return res;
  } catch (error) {
    logger.error(`Error escribiendo cntlm.conf para ${user}@${domain}: ${error.message}`);
    throw new Error('Error escribiendo cntlm.conf: ' + error.message);
  }
}

async function restartService() {
  try {
    const res = cntlmModule.restartCntlmService();
    logger.info('Servicio CNTLM reiniciado correctamente');
    return res;
  } catch (error) {
    logger.error('Error reiniciando CNTLM: ' + error.message);
    throw new Error('Error reiniciando CNTLM: ' + error.message);
  }
}

async function stopService() {
  try {
    const res = cntlmModule.stopCntlmService();
    logger.info('Servicio CNTLM detenido correctamente');
    return res;
  } catch (error) {
    logger.error('Error deteniendo CNTLM: ' + error.message);
    throw new Error('Error deteniendo CNTLM: ' + error.message);
  }
}

module.exports = {
  generateHashes,
  writeCntlmConf,
  restartService,
  stopService,
};
