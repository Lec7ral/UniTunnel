const metrics = require('../modules/metrics');
const logger = require('../utils/logger');
const { isValidLogLevel } = require('../utils/validation');

async function logEvent(level, message) {
  try {
    if (!level || !message) throw new Error('Nivel y mensaje son requeridos');
    if (!isValidLogLevel(level)) {
      logger.warn(`Nivel de log inválido: ${level}, usando 'info' por defecto`);
      level = 'info';
    }
    await metrics.log(level, message);
    logger.info(`Evento registrado: [${level}] ${message}`);
  } catch (error) {
    logger.error(`Error en logEvent: ${error.message}`);
    throw error;
  }
}

async function getLogs(limit = 100) {
  try {
    return await metrics.getRecentLogs(limit);
  } catch (error) {
    logger.error(`Error obteniendo logs: ${error.message}`);
    throw error;
  }
}

async function clearAllLogs() {
  try {
    await metrics.clearLogs();
    logger.info('Logs limpiados correctamente');
  } catch (error) {
    logger.error(`Error limpiando logs: ${error.message}`);
    throw error;
  }
}

module.exports = {
  logEvent,
  getLogs,
  clearAllLogs,
};
