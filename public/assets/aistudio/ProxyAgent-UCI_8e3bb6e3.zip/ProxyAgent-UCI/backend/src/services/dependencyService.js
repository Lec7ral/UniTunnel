const dependencyChecker = require('../modules/dependencyChecker');
const logger = require('../utils/logger');

async function listDependencies() {
  try {
    const deps = await dependencyChecker.checkAllDeps();
    logger.info('Verificación de dependencias completada con éxito');
    return deps;
  } catch (error) {
    logger.error('Error al listar dependencias: ' + error.message);
    throw new Error('Error al listar dependencias: ' + error.message);
  }
}

module.exports = {
  listDependencies,
};
