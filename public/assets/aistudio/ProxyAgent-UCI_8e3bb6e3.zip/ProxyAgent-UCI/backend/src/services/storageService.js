const storageModule = require('../modules/storage');
const logger = require('../utils/logger');

/**
 * Añade una cuenta y almacena su contraseña segura.
 */
async function addAccountWithPassword(accountData, password) {
  if (!accountData?.user || !accountData?.domain || !password) {
    throw new Error('Datos incompletos para añadir cuenta');
  }
  try {
    await storageModule.addAccount(accountData);
    await storageModule.storePassword(accountData.user, accountData.domain, password);
    logger.info(`Cuenta agregada: ${accountData.user}@${accountData.domain}`);
    return { success: true };
  } catch (error) {
    logger.error(`Error añadiendo cuenta: ${error.message}`);
    return { success: false, error: error.message };
  }
}

/**
 * Obtiene todas las cuentas con sus contraseñas ocultas.
 */
async function getAccounts() {
  try {
    return await storageModule.getAccounts();
  } catch (error) {
    logger.error(`Error obteniendo cuentas: ${error.message}`);
    return [];
  }
}

/**
 * Elimina una cuenta y su contraseña.
 */
async function deleteAccount(user, domain) {
  if (!user || !domain) {
    return { success: false, error: 'Usuario y dominio requeridos para eliminar cuenta' };
  }
  try {
    const accounts = await storageModule.getAccounts();
    const filtered = accounts.filter(a => !(a.user === user && a.domain === domain));
    await storageModule.saveAccounts(filtered);
    await storageModule.deletePassword(user, domain);
    logger.info(`Cuenta eliminada: ${user}@${domain}`);
    return { success: true };
  } catch (error) {
    logger.error(`Error eliminando cuenta: ${error.message}`);
    return { success: false, error: error.message };
  }
}

/**
 * Obtiene contraseña de una cuenta.
 */
async function getPassword(user, domain) {
  if (!user || !domain) {
    return null;
  }
  try {
    return await storageModule.getPassword(user, domain);
  } catch (error) {
    logger.error(`Error obteniendo contraseña: ${error.message}`);
    return null;
  }
}

/**
 * Actualiza una cuenta (sin modificar contraseña).
 */
async function updateAccount(updatedAccount) {
  if (!updatedAccount?.user || !updatedAccount?.domain) {
    return { success: false, error: 'Datos incompletos para actualizar cuenta' };
  }
  try {
    const accounts = await storageModule.getAccounts();
    const idx = accounts.findIndex(a => a.user === updatedAccount.user && a.domain === updatedAccount.domain);
    if (idx >= 0) {
      accounts[idx] = updatedAccount;
      await storageModule.saveAccounts(accounts);
      logger.info(`Cuenta actualizada: ${updatedAccount.user}@${updatedAccount.domain}`);
      return { success: true };
    }
    return { success: false, error: 'Cuenta no encontrada' };
  } catch (error) {
    logger.error(`Error actualizando cuenta: ${error.message}`);
    return { success: false, error: error.message };
  }
}

module.exports = {
  addAccountWithPassword,
  getAccounts,
  deleteAccount,
  getPassword,
  updateAccount
};
