const sshTunnelModule = require('../modules/sshTunnel');
const logger = require('../utils/logger');

let tunnelRunning = false;

/**
 * Inicia el túnel SSH dinámico.
 */
async function start() {
  if (tunnelRunning) {
    logger.warn('Intento de iniciar túnel SSH cuando ya está activo');
    return { success: false, error: 'El túnel ya está en ejecución.' };
  }
  try {
    const result = await sshTunnelModule.startTunnel();
    if (result.success) {
      tunnelRunning = true;
      logger.info('Túnel SSH iniciado correctamente');
    } else {
      logger.error(`Error al iniciar túnel SSH: ${result.error}`);
    }
    return result;
  } catch (error) {
    logger.error(`Excepción iniciando túnel SSH: ${error.message}`);
    return { success: false, error: error.message };
  }
}

/**
 * Detiene el túnel SSH dinámico.
 */
async function stop() {
  if (!tunnelRunning) {
    logger.warn('Intento de detener túnel SSH cuando no está activo');
    return { success: false, error: 'No hay ningún túnel activo.' };
  }
  try {
    const result = await sshTunnelModule.stopTunnel();
    if (result.success) {
      tunnelRunning = false;
      logger.info('Túnel SSH detenido correctamente');
    } else {
      logger.error(`Error al detener túnel SSH: ${result.error}`);
    }
    return result;
  } catch (error) {
    logger.error(`Excepción deteniendo túnel SSH: ${error.message}`);
    return { success: false, error: error.message };
  }
}

/**
 * Activa el proxy SOCKS (127.0.0.1:1080).
 */
async function enableSocks() {
  try {
    const result = await sshTunnelModule.enableSocks();
    if (result.success) {
      logger.info('Proxy SOCKS habilitado');
    } else {
      logger.error(`Error habilitando proxy SOCKS: ${result.error}`);
    }
    return result;
  } catch (error) {
    logger.error(`Excepción habilitando proxy SOCKS: ${error.message}`);
    return { success: false, error: error.message };
  }
}

/**
 * Desactiva el proxy SOCKS.
 */
async function disableSocks() {
  try {
    const result = await sshTunnelModule.disableSocks();
    if (result.success) {
      logger.info('Proxy SOCKS deshabilitado');
    } else {
      logger.error(`Error deshabilitando proxy SOCKS: ${result.error}`);
    }
    return result;
  } catch (error) {
    logger.error(`Excepción deshabilitando proxy SOCKS: ${error.message}`);
    return { success: false, error: error.message };
  }
}

module.exports = {
  start,
  stop,
  enableSocks,
  disableSocks
};
