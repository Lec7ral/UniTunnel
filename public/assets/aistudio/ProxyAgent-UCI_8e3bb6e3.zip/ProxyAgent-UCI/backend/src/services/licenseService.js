const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');
const { isValidUUID } = require('../utils/validation');

const publicKeyPath = path.join(__dirname, '..', 'config', 'public.key');
const publicKey = fs.readFileSync(publicKeyPath, 'utf8');

function verifyLicense(token, machineUUID) {
  try {
    if (!token) throw new Error('Token es requerido');
    if (!machineUUID || !isValidUUID(machineUUID)) {
      logger.warn(`UUID inválida para verificación: ${machineUUID}`);
      return { valid: false, reason: 'UUID inválida' };
    }

    const decoded = jwt.verify(token, publicKey, { algorithms: ['RS256'] });

    const now = Date.now();
    const start = new Date(decoded.startDate).getTime();
    const exp = decoded.exp * 1000;

    if (now < start) {
      logger.warn(`Licencia no válida aún: inicio ${decoded.startDate}`);
      return { valid: false, reason: 'Licencia no válida aún' };
    }
    if (now > exp) {
      logger.warn(`Licencia expirada: expiración ${new Date(exp).toISOString()}`);
      return { valid: false, reason: 'Licencia expirada' };
    }

    const normalizedUUIDToken = (decoded.uuid || '').toLowerCase().replace(/[\s\-]/g, '');
    const normalizedUUIDMachine = (machineUUID || '').toLowerCase().replace(/[\s\-]/g, '');

    if (!normalizedUUIDToken || normalizedUUIDToken !== normalizedUUIDMachine) {
      logger.warn(`UUID no coincide con licencia: token=${normalizedUUIDToken}, máquina=${normalizedUUIDMachine}`);
      return { valid: false, reason: 'UUID no coincide con licencia' };
    }

    logger.info(`Licencia verificada correctamente para usuario ${decoded.sub}`);
    return { valid: true, data: decoded };

  } catch (err) {
    logger.error(`Error verificando licencia: ${err.message}`);
    return { valid: false, reason: 'Licencia inválida: ' + err.message };
  }
}

module.exports = { verifyLicense };
