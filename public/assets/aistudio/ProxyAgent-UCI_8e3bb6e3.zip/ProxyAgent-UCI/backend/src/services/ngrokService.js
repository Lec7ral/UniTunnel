const ngrokTunnel = require('../modules/ngrokTunnel');
const logger = require('../utils/logger');

async function startTunnel() {
  try {
    const res = await ngrokTunnel.startNgrokTCP();
    if (!res.success) {
      logger.error(`Error al iniciar túnel ngrok: ${res.error}`);
      throw new Error(res.error);
    }
    logger.info('Túnel ngrok iniciado correctamente');
    return res;
  } catch (err) {
    logger.error(`Excepción en startTunnel: ${err.message}`);
    return { success: false, error: err.message };
  }
}

async function stopTunnel() {
  try {
    const res = await ngrokTunnel.stopNgrokTCP();
    if (!res.success) {
      logger.error(`Error al detener túnel ngrok: ${res.error}`);
      throw new Error(res.error);
    }
    logger.info('Túnel ngrok detenido correctamente');
    return res;
  } catch (err) {
    logger.error(`Excepción en stopTunnel: ${err.message}`);
    return { success: false, error: err.message };
  }
}

async function enableSocks() {
  try {
    const res = await ngrokTunnel.enableSystemSocks();
    if (!res.success) {
      logger.error(`Error al habilitar socks ngrok: ${res.error}`);
      throw new Error(res.error);
    }
    logger.info('SOCKS habilitado correctamente');
    return res;
  } catch (err) {
    logger.error(`Excepción en enableSocks: ${err.message}`);
    return { success: false, error: err.message };
  }
}

async function disableSocks() {
  try {
    const res = await ngrokTunnel.disableSystemSocks();
    if (!res.success) {
      logger.error(`Error al deshabilitar socks ngrok: ${res.error}`);
      throw new Error(res.error);
    }
    logger.info('SOCKS deshabilitado correctamente');
    return res;
  } catch (err) {
    logger.error(`Excepción en disableSocks: ${err.message}`);
    return { success: false, error: err.message };
  }
}

module.exports = {
  startTunnel,
  stopTunnel,
  enableSocks,
  disableSocks,
};
