const { ipcMain } = require('electron');
const cntlmService       = require('./services/cntlmService');
const systemProxyService = require('./services/systemProxyService');
const storageService     = require('./services/storageService');
const sshTunnelService   = require('./services/sshTunnelService');
const dependencyChecker  = require('./modules/dependencyChecker');
const metricsService     = require('./services/metricsService');
const licenseService     = require('./services/licenseService');
const { exec }           = require('child_process');

// CNTLM
ipcMain.handle('generate-hashes', async (event, data) => {
  if (!data?.user || !data?.domain || !data?.password) {
    return { success: false, error: 'Usuario, dominio y contraseña son requeridos' };
  }
  await metricsService.log('info', `Generando hashes para ${data.user}@${data.domain}`);
  try {
    const result = await cntlmService.generateHashes(data.user, data.domain, data.password);
    return { success: true, data: result };
  } catch (error) {
    await metricsService.log('error', `Error generando hashes: ${error.message}`);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('write-cntlm-conf', async (event, data) => {
  if (!data?.user || !data?.domain || !data?.passLM || !data?.passNT || !data?.passNTLMv2) {
    return { success: false, error: 'Datos incompletos para escribir cntlm.conf' };
  }
  await metricsService.log('info', `Escribiendo cntlm.conf para ${data.user}@${data.domain}`);
  try {
    const res = await cntlmService.writeCntlmConf(data.user, data.domain, data.passLM, data.passNT, data.passNTLMv2);
    return { success: true, data: res };
  } catch (error) {
    await metricsService.log('error', `Error escribiendo cntlm.conf: ${error.message}`);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('restart-cntlm-service', async () => {
  try {
    const res = await cntlmService.restartService();
    await metricsService.log(res.success ? 'info' : 'error', 'Reinicio servicio CNTLM');
    return res;
  } catch (error) {
    await metricsService.log('error', `Error reiniciando CNTLM: ${error.message}`);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('stop-cntlm-service', async () => {
  try {
    const res = await cntlmService.stopService();
    await metricsService.log(res.success ? 'info' : 'error', 'Detención servicio CNTLM');
    return res;
  } catch (error) {
    await metricsService.log('error', `Error deteniendo CNTLM: ${error.message}`);
    return { success: false, error: error.message };
  }
});

// SYSTEM PROXY
ipcMain.handle('set-system-proxy', async () => {
  try {
    const res = await systemProxyService.enableSystemProxy();
    await metricsService.log(res.success ? 'info' : 'error', res.success ? 'Proxy activado' : 'Error proxy');
    return res;
  } catch (error) {
    await metricsService.log('error', `Error activar proxy: ${error.message}`);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('disable-system-proxy', async () => {
  try {
    const res = await systemProxyService.disableSystemProxy();
    await metricsService.log(res.success ? 'info' : 'error', res.success ? 'Proxy desactivado' : 'Error proxy');
    return res;
  } catch (error) {
    await metricsService.log('error', `Error desactivar proxy: ${error.message}`);
    return { success: false, error: error.message };
  }
});

// STORAGE (CUENTAS)
ipcMain.handle('get-accounts', async () => {
  try {
    await metricsService.log('info', 'Consulta cuentas');
    const accounts = await storageService.getAccounts();
    return { success: true, data: accounts };
  } catch (error) {
    await metricsService.log('error', `Error consultando cuentas: ${error.message}`);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('add-account', async (event, data) => {
  if (!data?.user || !data?.domain || !data?.password) {
    return { success: false, error: 'Usuario, dominio y contraseña son requeridos' };
  }
  try {
    await storageService.addAccountWithPassword(
      { user: data.user, domain: data.domain, hashLM: data.hashLM, hashNT: data.hashNT, hashNTLMv2: data.hashNTLMv2 },
      data.password
    );
    await metricsService.log('info', `Cuenta agregada: ${data.user}@${data.domain}`);
    return { success: true };
  } catch (err) {
    await metricsService.log('error', `Error agregar cuenta: ${data.user}@${data.domain} - ${err.message}`);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('delete-account', async (event, data) => {
  if (!data?.user || !data?.domain) {
    return { success: false, error: 'Usuario y dominio son requeridos para eliminar cuenta' };
  }
  try {
    await storageService.deleteAccount(data.user, data.domain);
    await metricsService.log('info', `Cuenta eliminada: ${data.user}@${data.domain}`);
    return { success: true };
  } catch (err) {
    await metricsService.log('error', `Error eliminar cuenta: ${data.user}@${data.domain} - ${err.message}`);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('get-password', async (event, data) => {
  if (!data?.user || !data?.domain) {
    return { success: false, error: 'Usuario y dominio son requeridos para obtener contraseña' };
  }
  try {
    const password = await storageService.getPassword(data.user, data.domain);
    if (password) {
      await metricsService.log('info', `Contraseña recuperada para ${data.user}@${data.domain}`);
      return { success: true, password };
    } else {
      await metricsService.log('warn', `Contraseña no encontrada para ${data.user}@${data.domain}`);
      return { success: false, error: 'No password found' };
    }
  } catch (err) {
    await metricsService.log('error', `Error recuperar contraseña: ${data.user}@${data.domain} - ${err.message}`);
    return { success: false, error: err.message };
  }
});

// LOGS
ipcMain.handle('get-recent-logs', async (event, limit = 50) => {
  try {
    const logs = await metricsService.getLogs(limit);
    return { success: true, data: logs };
  } catch (error) {
    return { success: false, data: [] };
  }
});

// DEPENDENCIAS
ipcMain.handle('get-dependencies', async () => {
  try {
    const deps = dependencyChecker.checkAllDeps();
    await metricsService.log('info', 'Chequeo dependencias');
    return { success: true, deps };
  } catch (err) {
    await metricsService.log('error', `Error chequeo dependencias: ${err.message}`);
    return { success: false, error: err.message };
  }
});

// INSTALACION DE DEPENDENCIAS
ipcMain.handle('run-install-cmd', async (event, cmdString) => {
  return new Promise(resolve => {
    exec(cmdString, async (error, stdout, stderr) => {
      if (error) {
        await metricsService.log('error', `Error instalar: ${cmdString} - ${stderr || error.message}`);
        resolve({ success: false, error: stderr || error.message });
      } else {
        await metricsService.log('info', `Instalación completada: ${cmdString}`);
        resolve({ success: true });
      }
    });
  });
});

// SSH TUNNEL
ipcMain.handle('start-ssh-tunnel', async () => {
  try {
    const res = await sshTunnelService.start();
    await metricsService.log('info', 'Túnel SSH iniciado');
    return res;
  } catch (err) {
    await metricsService.log('error', `Error iniciar túnel SSH: ${err.message}`);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('stop-ssh-tunnel', async () => {
  try {
    const res = await sshTunnelService.stop();
    await metricsService.log('info', 'Túnel SSH detenido');
    return res;
  } catch (err) {
    await metricsService.log('error', `Error detener túnel SSH: ${err.message}`);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('enable-socks', async () => {
  try {
    const res = await sshTunnelService.enableSocks();
    await metricsService.log('info', 'SOCKS habilitado');
    return res;
  } catch (err) {
    await metricsService.log('error', `Error habilitar SOCKS: ${err.message}`);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('disable-socks', async () => {
  try {
    const res = await sshTunnelService.disableSocks();
    await metricsService.log('info', 'SOCKS deshabilitado');
    return res;
  } catch (err) {
    await metricsService.log('error', `Error deshabilitar SOCKS: ${err.message}`);
    return { success: false, error: err.message };
  }
});

// LICENCIA
ipcMain.handle('validate-license', async (event, { license, uuid }) => {
  if (!license || !uuid) {
    return { valid: false, reason: 'Licencia y UUID requeridos' };
  }
  try {
    const res = licenseService.verifyLicense(license, uuid);
    return res;
  } catch (err) {
    await metricsService.log('error', `Error validar licencia: ${err.message}`);
    return { valid: false, reason: err.message };
  }
});
