// components/appLauncher.js

export function initAppLauncher() {
  const appListContainer = document.getElementById('app-list');
  const btnLaunch        = document.getElementById('btn-launch');

  let appsGlobal = [];
  const selected = new Set();

  // Render list of checkboxes
  function renderApps() {
    appListContainer.innerHTML = '';
    appsGlobal.forEach((app, idx) => {
      const li       = document.createElement('li');
      const checkbox = document.createElement('input');
      checkbox.type  = 'checkbox';
      checkbox.id    = `app-checkbox-${idx}`;
      checkbox.value = idx;

      const label = document.createElement('label');
      label.htmlFor = checkbox.id;
      label.textContent = app.name;

      checkbox.addEventListener('change', e => {
        const i = Number(e.target.value);
        if (e.target.checked) selected.add(i);
        else             selected.delete(i);
        btnLaunch.disabled = selected.size === 0;
      });

      li.append(checkbox, label);
      appListContainer.appendChild(li);
    });

    // disable launch until any selected
    btnLaunch.disabled = true;
  }

  // Fetch from main process
  async function loadApps() {
    try {
      appsGlobal = await window.api.getAppList();
      renderApps();
    } catch (err) {
      console.error('Error al obtener lista de apps:', err);
    }
  }

  btnLaunch.addEventListener('click', async () => {
    if (selected.size === 0) return;

    btnLaunch.disabled   = true;
    btnLaunch.textContent = '🔄 Lanzando...';

    const results = await Promise.all(
      Array.from(selected).map(i => window.api.launchApp(appsGlobal[i]))
    );

    let msg = '';
    results.forEach(r => {
      if (r.success) msg += `✅ ${r.name} arrancó con proxy\n`;
      else           msg += `⚠️ ${r.name} NO pudo arrancar: ${r.error}\n`;
    });

    alert(msg);

    // reset UI
    selected.clear();
    await loadApps();
    btnLaunch.textContent = '🚀 Lanzar por Proxy';
  });

  // Initialize on module load
  loadApps();
}
