// components/sshTunnelUI.js

export function initSshTunnelUI() {
  const btnStartTunnel  = document.getElementById('btn-start-tunnel');
  const btnStopTunnel   = document.getElementById('btn-stop-tunnel');
  const btnEnableSocks  = document.getElementById('btn-enable-socks');
  const btnDisableSocks = document.getElementById('btn-disable-socks');
  const consoleDiv      = document.getElementById('console');

  function appendLog(text, type = 'info') {
    const line = document.createElement('div');
    line.textContent = text;
    if (type === 'error')   line.style.color = '#f44336';
    if (type === 'success') line.style.color = '#4caf50';
    consoleDiv.appendChild(line);
    consoleDiv.scrollTop = consoleDiv.scrollHeight;
  }

  btnStartTunnel.addEventListener('click', async () => {
    appendLog('🔄 Iniciando túnel SSH…');
    btnStartTunnel.disabled = true;
    const res = await window.api.startServeoTunnel();
    if (!res.success) {
      appendLog(`❌ ${res.error}`, 'error');
      return btnStartTunnel.disabled = false;
    }
    appendLog('⏳ Esperando a que el túnel arranque…');
    setTimeout(() => {
      btnStopTunnel.disabled   = false;
      btnEnableSocks.disabled  = false;
      appendLog('✅ Túnel SSH activo', 'success');
    }, 3000);
  });

  btnStopTunnel.addEventListener('click', async () => {
    appendLog('🛑 Deteniendo túnel SSH…');
    btnStopTunnel.disabled = true;
    const res = await window.api.stopServeoTunnel();
    if (res.success) {
      appendLog('✅ Túnel SSH detenido', 'success');
      btnStartTunnel.disabled  = false;
      btnEnableSocks.disabled  = true;
      btnDisableSocks.disabled = true;
    } else {
      appendLog(`❌ ${res.error}`, 'error');
      btnStopTunnel.disabled = false;
    }
  });

  btnEnableSocks.addEventListener('click', async () => {
    appendLog('🔧 Activando proxy SOCKS…');
    btnEnableSocks.disabled = true;
    const res = await window.api.enableSocks();
    if (res.success) {
      appendLog('✅ SOCKS5 activado en 127.0.0.1:1080', 'success');
      btnDisableSocks.disabled = false;
    } else {
      appendLog(`❌ ${res.error}`, 'error');
      btnEnableSocks.disabled = false;
    }
  });

  btnDisableSocks.addEventListener('click', async () => {
    appendLog('🛑 Desactivando proxy SOCKS…');
    btnDisableSocks.disabled = true;
    const res = await window.api.disableSocks();
    if (res.success) {
      appendLog('✅ SOCKS5 desactivado', 'success');
      btnEnableSocks.disabled = false;
    } else {
      appendLog(`❌ ${res.error}`, 'error');
      btnDisableSocks.disabled = false;
    }
  });
}
