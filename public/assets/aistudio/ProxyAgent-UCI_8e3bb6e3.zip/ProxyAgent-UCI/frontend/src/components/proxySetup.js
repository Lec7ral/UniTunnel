// src/components/proxySetup.js

import { refreshMetricsConsole } from './utils.js';

export function initProxySetup() {
  // Inputs & buttons
  const userInput    = document.getElementById('user');
  const domainInput  = document.getElementById('domain');
  const passInput    = document.getElementById('password');
  const btnConfigure = document.getElementById('btn-configure');
  const btnDisable   = document.getElementById('btn-disable');

  // Tunnel & SOCKS buttons
  const btnStartTunnel  = document.getElementById('btn-start-tunnel');
  const btnStopTunnel   = document.getElementById('btn-stop-tunnel');
  const btnEnableSocks  = document.getElementById('btn-enable-socks');
  const btnDisableSocks = document.getElementById('btn-disable-socks');

  const consoleDiv = document.getElementById('console');

  // Mejor helper de logs: ahora refresca desde métricas al final
  function appendLog(text, type = 'info') {
    const line = document.createElement('div');
    line.textContent = text;
    if (type === 'error')   line.style.color = '#f44336';
    if (type === 'success') line.style.color = '#4caf50';
    consoleDiv.appendChild(line);
    consoleDiv.scrollTop = consoleDiv.scrollHeight;
  }

  function setInputsDisabled(v) {
    [userInput, domainInput, passInput, btnConfigure, btnDisable].forEach(el => {
      el.disabled = v;
    });
  }

  // Configure proxy flow
  btnConfigure.addEventListener('click', async () => {
    const user   = userInput.value.trim();
    const domain = domainInput.value.trim();
    const pass   = passInput.value;

    if (!user || !pass) {
      appendLog('❗ Usuario y contraseña obligatorios.', 'error');
      return;
    }

    setInputsDisabled(true);
    appendLog('🔧 Configurando proxy…');

    // 1) generate hashes (nueva firma)
    appendLog(`🔑 Generando hashes para ${user}@${domain}…`);
    const h = await window.api.generateHashes({ user, domain, password: pass });
    if (!h || !h.passLM) {
      appendLog(`❌ Error generando hashes`, 'error');
      setInputsDisabled(false);
      return;
    }
    appendLog('✅ Hashes OK', 'success');

    // 2) write cntlm.conf
    appendLog('✍️ Escribiendo cntlm.conf…');
    const w = await window.api.writeCntlmConf({
      user, domain,
      passLM: h.passLM,
      passNT: h.passNT,
      passNTLMv2: h.passNTLMv2
    });
    if (!w || !w.success) {
      appendLog(`❌ ${w.error || 'Error escribiendo cntlm.conf'}`, 'error');
      setInputsDisabled(false);
      return;
    }
    appendLog('✅ cntlm.conf escrito', 'success');

    // 3) restart CNTLM
    appendLog('♻️ Reiniciando CNTLM…');
    const r = await window.api.restartCntlmService();
    if (!r || !r.success) {
      appendLog(`❌ ${r.error || 'Error reiniciando CNTLM'}`, 'error');
      setInputsDisabled(false);
      return;
    }
    appendLog('✅ CNTLM running', 'success');

    // 4) set system proxy
    appendLog('🌐 Habilitando proxy de sistema…');
    const p = await window.api.setSystemProxy();
    if (!p || !p.success) {
      appendLog(`❌ ${p.error || 'Error habilitando proxy de sistema'}`, 'error');
      setInputsDisabled(false);
      return;
    }
    appendLog('✅ Proxy de sistema ON', 'success');

    setInputsDisabled(false);
    btnStartTunnel.disabled = false;

    // Refresca la consola de métricas/logs
    refreshMetricsConsole('console', 50);
  });

  // Disable proxy flow
  btnDisable.addEventListener('click', async () => {
    setInputsDisabled(true);
    appendLog('🛑 Desactivando proxy…');

    const stop = await window.api.stopCntlmService();
    appendLog(stop && stop.success ? '✅ CNTLM detenido' : `❌ ${stop && stop.error}`, stop && stop.success ? 'success' : 'error');

    const disable = await window.api.disableSystemProxy();
    appendLog(disable && disable.success ? '✅ Proxy de sistema OFF' : `❌ ${disable && disable.error}`, disable && disable.success ? 'success' : 'error');

    setInputsDisabled(false);
    btnStartTunnel.disabled = true;
    btnEnableSocks.disabled = true;
    btnDisableSocks.disabled = true;
    btnStopTunnel.disabled = true;

    // Refresca la consola de métricas/logs
    refreshMetricsConsole('console', 50);
  });

  // SSH→ngrok Tunnel
  btnStartTunnel.addEventListener('click', async () => {
    appendLog('🔄 Iniciando túnel SSH…');
    btnStartTunnel.disabled = true;
    const res = await window.api.startServeoTunnel();
    if (!res || !res.success) {
      appendLog(`❌ ${res && res.error || 'Error iniciando túnel SSH'}`, 'error');
      btnStartTunnel.disabled = false;
      return;
    }
    appendLog('⏳ Esperando túnel…');
    setTimeout(() => {
      btnStopTunnel.disabled = false;
      btnEnableSocks.disabled = false;
      appendLog('✅ Túnel levantado', 'success');
      refreshMetricsConsole('console', 50);
    }, 3000);
  });

  btnStopTunnel.addEventListener('click', async () => {
    appendLog('🛑 Cerrando túnel…');
    btnStopTunnel.disabled = true;
    const res = await window.api.stopServeoTunnel();
    appendLog(res && res.success ? '✅ Túnel cerrado' : `❌ ${res && res.error}`, res && res.success ? 'success' : 'error');
    btnEnableSocks.disabled = true;
    btnStartTunnel.disabled = false;

    refreshMetricsConsole('console', 50);
  });

  // SOCKS
  btnEnableSocks.addEventListener('click', async () => {
    appendLog('🔧 Activando SOCKS…');
    btnEnableSocks.disabled = true;
    const res = await window.api.enableSocks();
    appendLog(res && res.success ? '✅ SOCKS ON' : `❌ ${res && res.error}`, res && res.success ? 'success' : 'error');
    if (res && res.success) btnDisableSocks.disabled = false;
    refreshMetricsConsole('console', 50);
  });

  btnDisableSocks.addEventListener('click', async () => {
    appendLog('🛑 Desactivando SOCKS…');
    btnDisableSocks.disabled = true;
    const res = await window.api.disableSocks();
    appendLog(res && res.success ? '✅ SOCKS OFF' : `❌ ${res && res.error}`, res && res.success ? 'success' : 'error');
    if (res && res.success) btnEnableSocks.disabled = false;
    refreshMetricsConsole('console', 50);
  });
}
