export function initAccounts() {
  const getAccounts   = () => window.api.getAccounts();
  const addAccount    = (data) => window.api.addAccount(data);
  const deleteAccount = (data) => window.api.deleteAccount(data);
  const generateHashes = (user, domain, password) =>
  window.api.generateHashes({ user, domain, password });
  const getPassword   = (user, domain) => window.api.getPassword(user, domain);

  const accountForm = document.getElementById('account-form');
  const accountList = document.getElementById('account-list');
  const btnAdd      = document.getElementById('btn-add-account');

  async function renderAccounts() {
    accountList.innerHTML = '';
    const accounts = (await getAccounts()) || [];
    if (!accounts.length) {
      accountList.innerHTML = '<div class="small">No hay cuentas guardadas.</div>';
      return;
    }
    accounts.forEach(acc => {
      const div = document.createElement('div');
      div.className = 'account-item';
      div.innerHTML = `
        <span title="${acc.user}@${acc.domain}">${acc.user} <span class="small">@${acc.domain}</span></span>
        <div>
          <button class="btn-fill" data-user="${acc.user}" data-domain="${acc.domain}">Rellenar</button>
          <button class="btn-del" data-user="${acc.user}" data-domain="${acc.domain}">🗑️</button>
        </div>
      `;
      accountList.appendChild(div);
    });

    // Eventos rellenar/borrar
    accountList.querySelectorAll('.btn-fill').forEach(btn => {
      btn.onclick = async () => {
        try {
          const user = btn.dataset.user;
          const domain = btn.dataset.domain;
          document.getElementById('acc-user').value = user;
          document.getElementById('acc-domain').value = domain;
          const res = await getPassword(user, domain);
          if (res && res.success) {
            document.getElementById('acc-password').value = res.password;
            appendLog('Password recuperado de Keychain', 'success');
          } else {
            document.getElementById('acc-password').value = '';
            appendLog('No se encontró la contraseña para esta cuenta.', 'warn');
          }
        } catch (err) {
          appendLog('Error inesperado rellenando: ' + (err.message || err), 'error');
        }
      };
    });

    accountList.querySelectorAll('.btn-del').forEach(btn => {
      btn.onclick = async () => {
        const user = btn.dataset.user;
        const domain = btn.dataset.domain;
        if (confirm(`¿Eliminar la cuenta ${user}@${domain}?`)) {
          try {
            const res = await deleteAccount({ user, domain });
            if (res.success) {
              appendLog(`Cuenta eliminada: ${user}@${domain}`, 'success');
            } else {
              appendLog(`Error al eliminar: ${res.error || 'desconocido'}`, 'error');
            }
            renderAccounts();
          } catch (err) {
            appendLog('Error inesperado borrando: ' + (err.message || err), 'error');
          }
        }
      };
    });
  }

  function appendLog(msg, level = 'info') {
    const logDiv = document.getElementById('console');
    if (!logDiv) return;
    const el = document.createElement('div');
    el.textContent = `[${level.toUpperCase()}] ${msg}`;
    el.className = `log-${level}`;
    logDiv.appendChild(el);
    logDiv.scrollTop = logDiv.scrollHeight;
  }

  btnAdd.addEventListener('click', async (e) => {
    e.preventDefault();
    try {
      const user = document.getElementById('acc-user').value.trim();
      const domain = document.getElementById('acc-domain').value.trim();
      const password = document.getElementById('acc-password').value;
      if (!user || !domain || !password) {
        appendLog('Faltan campos obligatorios', 'error');
        return;
      }
      const hashes = await generateHashes(user, domain, password);
      if (!hashes || !hashes.passLM) {
        appendLog('Error generando hashes NTLM', 'error');
        return;
      }
      const res = await addAccount({
        user,
        domain,
        password,
        hashLM: hashes.passLM,
        hashNT: hashes.passNT,
        hashNTLMv2: hashes.passNTLMv2
      });
      if (res.success) {
        appendLog(`Cuenta guardada: ${user}@${domain}`, 'success');
        accountForm.reset();
        renderAccounts();
      } else {
        appendLog(`Error guardando cuenta: ${res.error || 'desconocido'}`, 'error');
      }
    } catch (err) {
      appendLog('Error inesperado agregando: ' + (err.message || err), 'error');
    }
  });

  renderAccounts();
}
