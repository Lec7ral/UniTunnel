// src/components/utils.js

/**
 * Genera un panel DOM con la lista de dependencias.
 * deps: Array de { name, installed, install: { cmd, auto } }
 */
export function renderDependencyPanel(deps) {
  const container = document.getElementById('dependencies-container');
  if (!container) return;
  container.innerHTML = '<h3>Dependencias necesarias:</h3>';
  deps.forEach(dep => {
    const div = document.createElement('div');
    div.style.marginBottom = '8px';
    const status = dep.installed
      ? '<span style="color:var(--color-success)">Instalada</span>'
      : '<span style="color:var(--color-error)">Falta</span>';
    div.innerHTML = `<strong>${dep.name}</strong>: ${status}`;
    if (!dep.installed) {
      const info = document.createElement('div');
      info.style.margin = '4px 0 0 16px';
      info.style.fontSize = '0.9em';
      if (dep.install.auto) {
        info.innerHTML = `Se instalará con Brew: <code>${dep.install.cmd}</code>`;
        const btn = document.createElement('button');
        btn.textContent = 'Instalar';
        btn.style.marginTop = '4px';
        btn.addEventListener('click', async () => {
          btn.disabled = true;
          btn.textContent = 'Instalando…';
          const res = await window.api.runInstallCommand(dep.install.cmd);
          if (res.success) {
            btn.textContent = '✔️';
            setTimeout(() => location.reload(), 800);
          } else {
            btn.textContent = 'Error';
            console.error(res.error);
          }
        });
        info.appendChild(document.createElement('br'));
        info.appendChild(btn);
      } else {
        info.innerHTML = `Ejecuta en tu terminal:<br/><code>${dep.install.cmd}</code>`;
      }
      div.appendChild(info);
    }
    container.appendChild(div);
  });
}

// --- helpers genéricos ya existentes ---

/** Genera un UUID v4 rápido */
export function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(
    /[xy]/g,
    c => ((c === 'x' ? (Math.random() * 16) : ((Math.random() * 4) + 8)) | 0).toString(16)
  );
}

/** Vacía todos los hijos de un elemento */
export function clearElement(el) {
  while (el.firstChild) el.removeChild(el.firstChild);
}

/** Añade una línea de log en un “console” DOM */
export function appendLog(consoleEl, text, type = 'info') {
  const line = document.createElement('div');
  line.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
  if (type === 'error')   line.style.color = 'var(--color-error)';
  if (type === 'success') line.style.color = 'var(--color-success)';
  consoleEl.appendChild(line);
  consoleEl.scrollTop = consoleEl.scrollHeight;
}

/** Activa/Desactiva un array de elementos */
export function setDisabled(elements, disabled = true) {
  elements.forEach(el => el && (el.disabled = disabled));
}

/** Pausa ms milisegundos */
export function sleep(ms) {
  return new Promise(res => setTimeout(res, ms));
}

export async function refreshMetricsConsole(logDivId = 'console', limit = 50) {
  const logDiv = document.getElementById(logDivId);
  if (!logDiv) return;
  const logs = await window.api.getRecentLogs(limit);
  logDiv.innerHTML = ''; // Limpia
  logs.reverse().forEach(log => {
    const line = document.createElement('div');
    line.textContent = `[${log.timestamp}] [${log.level.toUpperCase()}] ${log.message}`;
    line.className = `log-${log.level}`;
    logDiv.appendChild(line);
  });
  logDiv.scrollTop = logDiv.scrollHeight;
}