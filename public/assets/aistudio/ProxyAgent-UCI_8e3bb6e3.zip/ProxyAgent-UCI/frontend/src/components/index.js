// components/index.js

import { renderDependencyPanel } from './utils.js';
import { initAccounts } from './accounts.js';
import { initProxySetup } from './proxySetup.js';
import { initSshTunnelUI } from './sshTunnelUI.js';
import { initAppLauncher } from './appLauncher.js';

window.addEventListener('DOMContentLoaded', async () => {
  // —————————————————————————————————————————
  // 1) Panel de dependencias
  // —————————————————————————————————————————
  const depsContainer = document.getElementById('dependencies-container');
  if (depsContainer) {
    depsContainer.innerHTML = 'Cargando dependencias…';
    try {
      const depsResult = await window.api.getDependencies();
      if (depsResult.success) {
        renderDependencyPanel(depsResult.deps);
      } else {
        depsContainer.innerHTML = `<p style="color:red;">Error al comprobar dependencias: ${depsResult.error}</p>`;
      }
    } catch (err) {
      depsContainer.innerHTML = `<p style="color:red;">Error inesperado: ${err.message}</p>`;
    }
  }

  // —————————————————————————————————————————
  // 2) Control de pestañas
  // —————————————————————————————————————————
  const tabs = document.querySelectorAll('.tab');
  const contents = document.querySelectorAll('.tab-content');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.getAttribute('data-tab');
      contents.forEach(c => c.id === target
        ? c.classList.add('active')
        : c.classList.remove('active')
      );
    });
  });

  // —————————————————————————————————————————
  // 3) Inicialización de cada sección
  // —————————————————————————————————————————
  initAccounts();        // Gestión de cuentas
  initProxySetup();      // Configuración de CNTLM + proxy
  initSshTunnelUI();     // Control de túnel SSH/ngrok + SOCKS
  initAppLauncher();     // Lanzamiento de apps con proxy
});

